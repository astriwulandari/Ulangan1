<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "php_crud";

$dbconnect = new mysqli("$host","$user","$pass","$db");

?>